package com.hunasys.labelsketch.common.dao.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hunasys.labelsketch.common.dao.CommonDao;
import com.hunasys.labelsketch.common.vo.CodeVo;

@Repository
public class CommonDaoImpl implements CommonDao {

    @Autowired
    @Resource(name = "sqlSession")
    private SqlSessionTemplate sqlsession;
    

    @Override
    public List<CodeVo> selectList(Map<String, Integer> page) {
        return sqlsession.selectList("com.hunasys.labelsketch.common.sqlmap.CodeSql.selectCodeList", page);
    }
    
}
