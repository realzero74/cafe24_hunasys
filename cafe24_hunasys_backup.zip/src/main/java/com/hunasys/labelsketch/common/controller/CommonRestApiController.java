package com.hunasys.labelsketch.common.controller;

public class CommonRestApiController {

}
