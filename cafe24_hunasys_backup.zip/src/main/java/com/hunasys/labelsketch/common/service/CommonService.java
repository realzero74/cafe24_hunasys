package com.hunasys.labelsketch.common.service;

public interface CommonService {

}
