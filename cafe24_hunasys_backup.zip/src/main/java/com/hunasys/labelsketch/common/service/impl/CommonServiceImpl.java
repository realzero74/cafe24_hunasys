package com.hunasys.labelsketch.common.service.impl;

import com.hunasys.labelsketch.common.service.CommonService;

public class CommonServiceImpl implements CommonService {

}
