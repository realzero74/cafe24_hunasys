package com.hunasys.labelsketch.common.vo;

public class FileVo {

}
