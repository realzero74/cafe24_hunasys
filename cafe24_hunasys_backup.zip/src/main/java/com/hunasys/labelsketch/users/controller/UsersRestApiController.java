package com.hunasys.labelsketch.users.controller;

public class UsersRestApiController {

}
