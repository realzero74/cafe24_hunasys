package com.hunasys.labelsketch.users.dao.impl;

import com.hunasys.labelsketch.users.dao.UsersDao;

public class UsersDaoImpl implements UsersDao {

}
