package com.hunasys.labelsketch.users.vo;

public class UsersVo {

}
