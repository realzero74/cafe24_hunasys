package com.hunasys.labelsketch.users.dao;

public interface UsersDao {

}
