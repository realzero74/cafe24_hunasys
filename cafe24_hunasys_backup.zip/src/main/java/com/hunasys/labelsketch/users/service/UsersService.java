package com.hunasys.labelsketch.users.service;

public interface UsersService {

}
