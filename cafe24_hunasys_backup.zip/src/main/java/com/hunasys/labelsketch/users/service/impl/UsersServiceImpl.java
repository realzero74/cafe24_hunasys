package com.hunasys.labelsketch.users.service.impl;

import com.hunasys.labelsketch.users.service.UsersService;

public class UsersServiceImpl implements UsersService {

}
